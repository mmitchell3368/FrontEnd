const express = require('express');
const { MongoClient } = require('mongodb');

const app = express();
const port = 3000;

// Replace with your MongoDB connection string
const uri = 'mongodb://localhost:27017/';
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

async function connectToDatabase() {
    try {
        await client.connect();
        console.log('Connected to MongoDB');
    } catch (error) {
        console.error('Error connecting to MongoDB:', error);
    }
}

connectToDatabase();

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

// ... (previous code)

app.use(express.json());

app.post('/submit', async (req, res) => {
    const formData = req.body;

    const db = client.db('MitchellsPub');
    const collection = db.collection('Reservation');

    try {
        await collection.insertOne(formData);
        console.log('Form data inserted into MongoDB');
        res.status(200).send('Form data inserted');
    } catch (error) {
        console.error('Error inserting form data:', error);
        res.status(500).send('Error inserting form data');
    }
});

