
/* Contact form code*/
document.getElementById('reservationForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Get form values
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const time = document.getElementById('time').value;

    // Perform form validation (example: checking if fields are not empty)
    if (name.trim() === '' || email.trim() === '' || phone.trim() === '' || time.trim() === '') {
        alert('Please fill in all fields.');
        return;
    }

    // Create a data object to send to the server
    const formData = {
        name: name,
        email: email,
        phone: phone,
        time: time
    };

    // Send the data to the server using fetch
    fetch('/submit', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.text())
    .then(data => {
        console.log(data); // Log the server response
        // Optionally, you can show a success message to the user
        alert('Reservation/Contact form submitted successfully!');
    })
    .catch(error => {
        console.error('Error:', error);
        // Optionally, you can show an error message to the user
        alert('An error occurred while submitting the form.');
    });

    // Optionally, you can clear the form after submission
    document.getElementById('reservationForm').reset();

});
